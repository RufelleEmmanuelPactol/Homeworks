from sqlalchemy import create_engine, text
import os
import pandas as pd
import dotenv
dotenv.load_dotenv()

def run_query(query):
    query_text = text(query)
    engine = create_engine(os.getenv("IQ_DB_AUTH"))
    connection = engine.connect()
    df = pd.read_sql_query(query_text, connection)
    return df

